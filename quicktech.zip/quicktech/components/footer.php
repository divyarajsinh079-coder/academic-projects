<footer class="footer">

   <section class="grid">

      <div class="box">
         <h3>Quick Links</h3>
         <a href="home.php"> <i class="fas fa-chevron-right"></i> Home</a>
         <a href="about.php"> <i class="fas fa-chevron-right"></i> About Us</a>
         <a href="shop.php"> <i class="fas fa-chevron-right"></i> Shop</a>
         <a href="contact.php"> <i class="fas fa-chevron-right"></i> Contact</a>
      </div>

      <div class="box">
         <h3>Customer Area</h3>
         <a href="user_login.php"> <i class="fas fa-chevron-right"></i> Sign In</a>
         <a href="user_register.php"> <i class="fas fa-chevron-right"></i> Create Account</a>
         <a href="cart.php"> <i class="fas fa-chevron-right"></i> Shopping Cart</a>
         <a href="orders.php"> <i class="fas fa-chevron-right"></i> My Orders</a>
      </div>

      <div class="box">
         <h3>Get In Touch</h3>
         <a href="tel:9800000000"><i class="fas fa-phone-alt"></i> +91 980 526 6670</a>
         <a href="tel:9900000000"><i class="fas fa-phone-alt"></i> +91 974 524 3220</a>
         <a href="mailto:callmejadeja@gmail.com"><i class="fas fa-envelope"></i> callmejadeja@gmail.com</a>
         <a href="https://goo.gl/maps/YourLocation"><i class="fas fa-map-marker-alt"></i> Bhavnagar, Gujarat, India</a>
      </div>

      <div class="box">
         <h3>Connect With Us</h3>
         <a href="https://www.facebook.com/jadeja_797_dj" target="_blank"><i class="fab fa-facebook-f"></i> Facebook</a>
         <a href="https://twitter.com/jadeja_797" target="_blank"><i class="fab fa-twitter"></i> Twitter</a>
         <a href="https://www.instagram.com/jadeja_797_dj/" target="_blank"><i class="fab fa-instagram"></i> Instagram</a>
         <a href="https://www.linkedin.com/in/jadeja_797_dj" target="_blank"><i class="fab fa-linkedin-in"></i> LinkedIn</a>
      </div>

   </section>

   <div class="credit">
      <p>&copy; <?= date('Y'); ?> quicktech.com | All Rights Reserved</p>
      <p>Crafted with <i class="fas fa-heart"></i> in India</p>
   </div>

</footer>